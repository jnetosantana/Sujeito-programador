
export function Cart(){
  return(
    <div>
      <h1>Pagina carrinho de compras</h1>
    </div>
  )
}