
export function Home(){
  return(
    <div>
      <h1>Pagina HOME</h1>
    </div>
  )
}