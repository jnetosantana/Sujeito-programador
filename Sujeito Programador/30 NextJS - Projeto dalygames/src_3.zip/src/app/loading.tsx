export default function Loading(){
  return(
    <div>
      <strong>Carregando informaçoes...</strong>
    </div>
  )
}