
export default function Admin(){
  return(
    <div>
      <h1>Página Admin</h1>
    </div>
  )
}