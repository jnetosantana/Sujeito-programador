export default function Cliente(){
  return(
    <div>
      <h1>Página do Clinte Admin</h1>
    </div>
  )
}