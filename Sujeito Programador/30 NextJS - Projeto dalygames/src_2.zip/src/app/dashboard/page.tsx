
export default function Dashboard(){
  return(
    <div>
      <h1>Página painel</h1>
      <span>Bem vindo ao painel do site</span>
      <br/>
      
    </div>
  )
}