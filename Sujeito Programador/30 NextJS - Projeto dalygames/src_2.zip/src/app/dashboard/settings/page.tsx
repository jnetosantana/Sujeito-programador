
export default function Settings(){
  return(
    <div>
      <h1>Página settings</h1>
      <h3>Essa pagina é a configuraçao do painel...</h3>
    </div>
  )
}