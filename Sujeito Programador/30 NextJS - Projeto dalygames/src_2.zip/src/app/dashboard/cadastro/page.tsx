
export default function Cadastro(){
  return(
    <div>
      <h1>Cadastrando cliente</h1>
      <p>Essa é a pagina de cadastro de clientes do dashboard</p>
    </div>
  )
}