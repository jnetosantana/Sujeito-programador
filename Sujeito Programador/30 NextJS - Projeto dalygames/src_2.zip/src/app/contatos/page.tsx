
export default function Contatos(){
  return(
    <div>
      <h1>Página de contatos</h1>
      <span>(xx) 000230-2323</span>
    </div>
  )
}