

export default function Home() {
  return (
    <main>
      <h1>Página HOME</h1>
      <span>Usando api routes</span>
    </main>
  )
}
