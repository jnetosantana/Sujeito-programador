

let userId: number | string;

userId = 123;


// console.log(typeof userId);
console.log(userId);