

// Tupla nao possui no JS e sim apenas com TS

let aluno: [string, number]; // precisa seguir a mesma ordem passada.

aluno = ["Sujeito Programador", 123]

aluno.push("Matheus", 4321)

// console.log(aluno);

let statusPedido: [string, string, string];

statusPedido = ["Em producao", "Saiu para entrega", "Pedido entregue"]

console.log(statusPedido);