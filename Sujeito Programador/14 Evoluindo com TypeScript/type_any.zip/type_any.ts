

// Type ANY | Ou seja qualquer coisa, Nao é legal usar!

let precoProduto;

precoProduto = true;

precoProduto = 25.90;

precoProduto = "Sujeito Programador"

let nota1: any;
let nota2: any;

nota1 = 10;
nota2 = 20;

nota1 = "15";

console.log(precoProduto);

console.log(nota1 + nota2);

