

// Type Array.


// let filmes: Array<string>;
// let filmes: string[];

// let filmes: Array<string | number>;
let filmes: (string | number)[];

filmes = ["Filme 1", "Filme 2"]

filmes.push(15)

console.log("Meus filmes ", filmes)




// let numeros: number[];
// numeros = [1, 5, 21, 30]

// console.log(numeros);

// numeros.push(55);

// console.log('Meus numeros: ', numeros)