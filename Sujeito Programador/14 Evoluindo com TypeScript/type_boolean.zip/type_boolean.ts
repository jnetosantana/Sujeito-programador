

// Type BOOLEAN

let estaAutenticado: boolean = true;

// estaAutenticado = false

let codeStatus: string = '';

// Tudo que for diferente de zero, string vazia, undefined, será verdadeiro.
estaAutenticado =  Boolean(codeStatus);

console.log(estaAutenticado);

