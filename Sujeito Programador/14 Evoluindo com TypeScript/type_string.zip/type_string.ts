
let tecnologia: string;


tecnologia = "JavaScript"



console.log(tecnologia)