
//Type number =  (int, float, hex, binary)
let valor1: number = 10;

valor1 = 20.90;

let valor2: number;

valor2 = 15

console.log(valor1 + valor2);