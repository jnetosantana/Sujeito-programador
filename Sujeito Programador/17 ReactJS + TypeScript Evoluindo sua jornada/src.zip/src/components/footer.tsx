
export function Footer(){
  return(
    <footer>
      <h4>Todos direitos reservados - @curso</h4>
    </footer>
  )
}