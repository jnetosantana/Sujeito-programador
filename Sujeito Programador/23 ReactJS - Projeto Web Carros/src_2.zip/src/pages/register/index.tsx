export function Register() {
  return (
    <div>
      <h1>Pagina Cadastro</h1>
    </div>
  )
}