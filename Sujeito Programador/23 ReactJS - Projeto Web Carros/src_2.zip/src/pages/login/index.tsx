export function Login() {
  return (
    <div>
      <h1>Pagina Login</h1>
    </div>
  )
}