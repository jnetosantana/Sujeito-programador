export function New() {
  return (
    <div>
      <h1>Pagina Cadastrar carro</h1>
    </div>
  )
}