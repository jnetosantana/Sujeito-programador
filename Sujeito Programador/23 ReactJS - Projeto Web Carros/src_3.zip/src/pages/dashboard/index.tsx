export function Dashboard() {
  return (
    <div>
      <h1>Pagina Dashboard</h1>
    </div>
  )
}