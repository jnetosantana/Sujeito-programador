export function CarDetail() {
  return (
    <div>
      <h1>Pagina Detalhes</h1>
    </div>
  )
}