
export function Home(){
  return(
    <div>
      <h1>Página Home</h1>
    </div>
  )
}