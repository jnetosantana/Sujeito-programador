

// Criar um bloco que agrupa varios testes relacionados
describe("First test app component", () => {

  it("should adds 1 + 2 to equal 3", () => {
      expect(1).toBe(1);
  })

})


export default {}