
import './App.css'

function App() {

  return (
    <div>
      <h1>Sujeito Programador</h1>
      <p>TESTE</p>
    </div>
  )
}

export default App
