import { useState } from 'react'
import './App.css'

function App() {
  const [message, setMessage] = useState("Bem vindo ao projeto!")

  return (
    <div>
      <h1 className="titulo" data-testid="header" >Sujeito Programador</h1>
      <p>{message}</p>

      <h1>Sujeito Programador</h1>

      <button onClick={ () => setMessage("Estudando testes com reactjs") }>
        Alterar mensagem
      </button>

    </div>
  )
}

export default App
