import styles from './home.module.css'

export function Home(){
  return(
    <div className={styles.container}>
      <h1>Pagina Home!!!!!!!!!</h1>
    </div>
  )
}