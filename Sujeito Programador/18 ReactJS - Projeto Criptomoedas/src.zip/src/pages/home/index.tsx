
export function Home(){
  return(
    <div>
      <h1>Pagina Home</h1>
    </div>
  )
}