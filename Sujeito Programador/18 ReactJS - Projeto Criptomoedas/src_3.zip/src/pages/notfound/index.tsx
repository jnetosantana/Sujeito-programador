
export function Notfound(){
  return(
    <div>
      <h1>Pagina 404 nao existe</h1>
    </div>
  )
}