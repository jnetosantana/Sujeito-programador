

export default function Home() {
  return (
    <div>
      <h1>Sujeito Pizza :)</h1>
    </div>
  )
}
