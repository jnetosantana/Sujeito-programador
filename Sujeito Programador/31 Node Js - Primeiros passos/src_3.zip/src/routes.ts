import { Router, Request, Response, NextFunction } from 'express'

const router = Router();

const tarefas = ["Estudar Node JS", 'Estudar JavaScript']

/* Entendendo Middlewares
 - Está ali no meio após chamar a requisiçao e antes e chamar o callback
*/

router.use((req: Request, res: Response, next: NextFunction ) => {
  console.log("PASSOU PELO MIDDLEWARE GLOBAL")

  return next();
})


//Listar todas tarefas
router.get("/tarefas", (req: Request, res: Response) => {
  res.json(tarefas)
})

//Listar unica tarefa
router.get("/tarefa/:index", (req: Request, res: Response) => {
  const index = req.params.index;
  
  res.json({ tarefa: tarefas[Number(index)] })
})

//Cadastrar nova tarefa
router.post("/tarefa", (req: Request, res: Response) => {

  const { nome } = req.body;

  if(!nome){
    res.status(400).json({ message: "Erro ao cadastrar" })
    return;
  }

  tarefas.push(nome)

  res.json(tarefas)


})


//Atualizar uma única tarefa
router.put("/tarefa/:index", (req: Request, res: Response) => {

  const { index } = req.params;
  const { nome } = req.body;

  tarefas[Number(index)] = nome;

  res.json(tarefas);
})


//Deletar alguma tarefa
router.delete("/tarefa/:index" , (req: Request, res: Response) => {
  const { index } = req.params;

  tarefas.splice(Number(index), 1)

  res.json({ message: "Tarefa deletada com sucesso!" })  

})


export { router };