import { Router, Request, Response } from 'express'

const router = Router();

// Query Params ?nome=Comrpar Pao
// Route Params /tarefas/2
// Request Body { nome: "Comprar Pao", "usuario": 123 }


// router.get("/tarefas", (req: Request, res: Response) => {

//   const nome = req.query.nome;

//   res.json({ tarefa: nome })
// })


router.get("/tarefas/:id", (req: Request, res: Response) => {

  const id = req.params.id;

  res.json({ tarefa: `Tarefa com id: ${id}` })
})

export { router };