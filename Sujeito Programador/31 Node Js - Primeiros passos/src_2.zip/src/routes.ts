import { Router, Request, Response } from 'express'

const router = Router();

const tarefas = ["Estudar Node JS", 'Estudar JavaScript']

//Listar todas tarefas
router.get("/tarefas", (req: Request, res: Response) => {
  res.json(tarefas)
})

//Listar unica tarefa
router.get("/tarefa/:index", (req: Request, res: Response) => {
  const index = req.params.index;
  
  res.json({ tarefa: tarefas[Number(index)] })
})

//Cadastrar nova tarefa
router.post("/tarefa", (req: Request, res: Response) => {

  const { nome } = req.body;

  if(!nome){
    res.status(400).json({ message: "Erro ao cadastrar" })
    return;
  }

  tarefas.push(nome)

  res.json(tarefas)


})




export { router };